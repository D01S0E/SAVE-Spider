let sec = document.querySelectorAll('section');
let links = document.querySelectorAll('nav a');

window.onscroll = () => {
    sec.forEach(section => {
        let top = window.scrollY;
        let offset = section.offsetTop;
        let height = section.offsetHeight;
        let id = section.getAttribute('id');

        if (top >= offset && top < offset + height) {
            links.forEach(link => {
                link.classList.remove('active');
                document.querySelector('nav a[href*=' + id + ']').classList.add('active');
            })
        }
    });
};



// input 요소 가져오기
const targetInput = document.getElementById("target");

// 값이 변경될 때마다 이벤트를 감지하고 값을 출력할 위치에 추가
targetInput.addEventListener("input", function () {
    const inputValue = targetInput.value;
    const outputContainer = document.getElementById("output");
    // 값을 출력할 위치에 추가
    outputContainer.textContent = "To be analyzed: " + inputValue;
});

// 엑셀 파일로 저장하는 함수
function exportToExcel() {
    const crawlData = Array.from(document.querySelectorAll("#crawl p")).map(p => [p.textContent]);
    const fuzzData = Array.from(document.querySelectorAll("#Fuzz p")).map(p => [p.textContent]);
    const successData = Array.from(document.querySelectorAll("#success p")).map(p => [p.textContent]);

    const wsCrawl = XLSX.utils.aoa_to_sheet(crawlData);
    const wsFuzz = XLSX.utils.aoa_to_sheet(fuzzData);
    const wsSuccess = XLSX.utils.aoa_to_sheet(successData);

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, wsCrawl, "파싱 URL 리스트");
    XLSX.utils.book_append_sheet(wb, wsFuzz, "공격 대상 URL 리스트");
    XLSX.utils.book_append_sheet(wb, wsSuccess, "공격 성공 페이로드(취약점)");

    XLSX.writeFile(wb, "Analysis_Result_SAVE-FUZZER.xlsx");
}

document.getElementById("downloadExcel").addEventListener("click", exportToExcel);