from urllib.parse import urlparse
from urllib import parse
from urllib.parse import parse_qs, urlencode

def remove_duplicated_line(target_file):
    no_dup_lines = set() # set is O(1), better then list O(n)
    with open(target_file, 'r+', encoding='utf-8') as fp:
        file_lines = fp.readlines()
        fp.seek(0)
        for line in file_lines:
            if line not in no_dup_lines:
                fp.write(line)
                no_dup_lines.add(line)
        fp.truncate()

def replace_param_save(filename, url, method):
    f = open(f'{filename}-Fuzz.txt', 'a', encoding='utf-8')

    parts = urlparse(url)
    params = parse_qs(parts.query)
    values = parts.query.split('&')
    
    for i in params:
        params[i] = 'FuZZ1nG'
    for i in values:
        param = i.split('=')[0]
        try:    params[param]
        except: params[param] = ['']

    if parse.unquote(urlencode(params)) != "=['']":
        url = f'{parts.scheme}://{parts.netloc}{parts.path}?{parse.unquote(urlencode(params))}'.replace("['']", '')
        f.write(f'{url}:::{method}')
        remove_duplicated_line(f'{filename}-Fuzz.txt')

def fuzz_file(filename):
    with open(f'{filename}.txt', 'r', encoding='utf-8') as f:
        for line in f:
            tmp = line.split(':::')
            replace_param_save(filename, tmp[0], tmp[1])