import os
import random
import socket
import binascii
from modules.attack import exploit
from modules.scanner import spider, session
from modules.make_fuzz_file import fuzz_file
from flask import Flask, render_template, jsonify, request, send_file

app = Flask(__name__)
app.secret_key = os.urandom(16)

def get_sesseion(url, data):
    print(data)
    session.post(url, data=data)

def start(target, server, port, filename, login=None, data=None):
    if login:
        get_sesseion(login, data)
    # session.post("http://192.168.175.219/cve_project/ajax.php?action=login", data=data)
    spider(target, filename)
    fuzz_file(filename)
    print("[+] Target Scrap Done !!!")
    print("[+] Starting Exploit !!!")
    if login:
        get_sesseion(login, data) # 다른 파일에서 불러오는 거라 새로 세션을 생성해야함
    exploit(server, port, filename)


@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == "GET":
        return render_template("index.html")
    elif request.method == "POST":
        target = request.form['site']
        loginURL = "http://13.124.97.60/gaatitrack//ajax.php?action=login"
        id = "mayuri.infospace@gmail.com"
        password = "admin"

        filename = binascii.hexlify(os.urandom(16)).decode()
        server = socket.gethostbyname(socket.getfqdn())
        port = random.randint(50000, 60000)
        if loginURL:
            start(target, server, port, filename, loginURL, {'email':id, "password":password})
        else:
            start(target, server, port, filename)
        start(target, server, port, filename)
        return render_template('index.html', target=target, filename=filename)
    
@app.route('/download/<filename>')
def Download_File(filename):
    PATH=f'../{filename}'
    return send_file(PATH,as_attachment=True)

@app.route('/crawl', methods=['POST'])
def update():
    filename = request.get_json()['filename']
    try:
        with open(f'{filename}.txt', 'r', encoding='utf-8') as f:
            lines = [i for i in f.readlines()]
        return jsonify(result="success", result2=lines)
    except: 
        return jsonify(result="success", result2="")

@app.route('/fuzset', methods=['POST'])
def fuzset():
    filename = request.get_json()['filename']
    try:
        with open(f'{filename}-FUZZ.txt', 'r', encoding='utf-8') as f:
            lines = [i for i in f.readlines()]
        return jsonify(result="success", result2=lines)
    except: 
        return jsonify(result="success", result2="")
    
@app.route('/success', methods=['POST'])
def success():
    filename = request.get_json()['filename']
    try:
        with open(f'{filename}-Success.txt', 'r', encoding='utf-8') as f:
            lines = [i for i in f.readlines()]
        return jsonify(result="success", result2=lines)
    except: 
        return jsonify(result="success", result2="")
    
@app.route('/fail', methods=['POST'])
def fail():
    filename = request.get_json()['filename']
    try:
        with open(f'{filename}-Fail.txt', 'r', encoding='utf-8') as f:
            lines = [i for i in f.readlines()]
        return jsonify(result="success", result2=lines)
    except: 
        return jsonify(result="success", result2="")

if __name__ == "__main__":
    app.run(port=3452, debug=True)