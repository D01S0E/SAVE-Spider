import requests
from urllib import parse
from bs4 import BeautifulSoup
from urllib.parse import urlparse
session = requests.Session()
# save url to already crawl
wait_url, end_url = set([]), set([])
data = ""
count = 0

def make_url(url):
    if not url.startswith(base_url):
        url = base_url+'/'+url.replace('./', '')
    return url

def request_page(url):
    url = make_url(url)
    r = session.get(url)
    if url in wait_url:
        wait_url.remove(url)
    end_url.add(url)
    return BeautifulSoup(r.text, 'html.parser')

def a_tag_parsing(soup):
    a_tags = soup.find_all('a')
    links = set([])
    for i in a_tags:
        try:
            links.add(i.attrs['href'])
        except KeyError:
            continue
    return links

def make_form_url(method, action, values):
    prefix = action if 'http://' in action or 'https://' in action else base_url
    prefix += ''.join(f'?{value}' if idx == 0 else f'&{value}' for idx, value in enumerate(values))
    if check_host(prefix):
        if prefix not in end_url:
            end_url.add(prefix)
            save_url(prefix, method.upper())
        

def form_tag_parsing(soup, link):
    form_tags = soup.find_all('form')
    for i in form_tags:
        method = i.get('method')

        if method == None:
            method = 'GET'
            
        action = i.get('action')
        tmp = [f"{j.get('name')}={j.get('value')}" for j in i.find_all("input")]

        if action == None:
            action = link
        make_form_url(method, action, tmp)

def tag_parsing(soup, link):
    a_tags = a_tag_parsing(soup)
    form_tag_parsing(soup, link)
    return a_tags

def check_host(url):
    url  = urlparse(url).netloc
    host = urlparse(base_url).netloc
    if url == host or url == '':
        return True
    return False

def save_url(url, method):
    global data, count

    url = url.replace("&None=submit","").replace("&None=None","")
    if method == "POST":
        data += f'{parse.unquote(url)}:::POST\n'
        count += 1

    else:
        if not check_host(url):
            return
        url = make_url(url)
        if url in wait_url or url in end_url:
            return
        wait_url.add(url)
        data += f'{parse.unquote(url)}:::{method}\n'
        count += 1

def spider(url, file):
    global filename, base_url, wait_url, end_url
    
    base_url, filename = url, file
    wait_url.add(base_url)
    
    while True: 
        if wait_url == set():
            break
        for url in list(wait_url):
            soup = request_page(url)
            for link in tag_parsing(soup, url):
                save_url(link, 'GET')
            end_url.add(url)

    f = open(f'{filename}.txt', 'w', encoding='utf-8')
    print(f'[+] Total Scrap Count {count}')
    f.write(data)
    f.close()